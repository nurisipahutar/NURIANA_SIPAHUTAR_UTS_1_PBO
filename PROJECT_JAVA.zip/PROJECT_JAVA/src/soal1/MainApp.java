package soal1;

public class MainApp {

    public static void main(String[] args) {
        // Polymorphism: Vehicle sebagai tipe data, objek bisa Car atau Motorcycle
        Vehicle myCar = new Car();
        Vehicle myMotorcycle = new Motorcycle();

        // Panggil method startEngine yang di-override di masing-masing subclass
        myCar.startEngine();           // Output: Car engine started with key ignition.
        myMotorcycle.startEngine();    // Output: Motorcycle engine started with kick start.

        // Karena myCar adalah instance Car, kita cek apakah ia Electric, lalu cast dan panggil chargeBattery()
        if (myCar instanceof Electric) {
            ((Electric) myCar).chargeBattery();
        }
    }
}
