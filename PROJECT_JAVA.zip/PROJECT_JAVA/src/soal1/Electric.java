package soal1;

public interface Electric {
    void chargeBattery();
}