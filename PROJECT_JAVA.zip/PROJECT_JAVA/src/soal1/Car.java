package soal1;

public class Car extends Vehicle implements Electric {

    @Override
    public void startEngine() {
        System.out.println("Car engine started with key ignition.");
    }

    @Override
    public void chargeBattery() {
        System.out.println("Car battery is charging...");
    }
}