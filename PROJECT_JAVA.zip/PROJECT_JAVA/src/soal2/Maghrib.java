package soal2;

public class Maghrib extends Prayer implements AudioReminder {

    public Maghrib(String time) {
        super(time);
    }

    @Override
    public void remind() {
        System.out.println("Reminder: Waktunya Sholat Maghrib pukul " + time);
    }

    @Override
    public void playAdzan() {
        System.out.println("Memutar adzan Maghrib...");
    }
}