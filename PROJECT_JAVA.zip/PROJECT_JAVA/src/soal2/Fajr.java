package soal2;

public class Fajr extends Prayer implements AudioReminder {

    public Fajr(String time) {
        super(time);
    }

    @Override
    public void remind() {
        System.out.println("Reminder: Waktunya Sholat Subuh pukul " + time);
    }

    @Override
    public void playAdzan() {
        System.out.println("Memutar adzan Subuh...");
    }
}
