package soal2;

public class Isha extends Prayer implements AudioReminder {

    public Isha(String time) {
        super(time);
    }

    @Override
    public void remind() {
        System.out.println("Reminder: Waktunya Sholat Isya pukul " + time);
    }

    @Override
    public void playAdzan() {
        System.out.println("Memutar adzan Isya...");
    }
}