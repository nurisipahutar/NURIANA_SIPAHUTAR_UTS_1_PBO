package soal2;

// Abstract class Prayer sebagai blueprint untuk jadwal sholat
public abstract class Prayer {
    protected String time;  // Waktu sholat, misal "04:52"

    public Prayer(String time) {
        this.time = time;
    }

    // Method abstrak remind, setiap subclass punya implementasi berbeda
    public abstract void remind();

    public String getTime() {
        return time;
    }
}
