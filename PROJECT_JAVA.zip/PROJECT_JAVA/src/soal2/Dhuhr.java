package soal2;

public class Dhuhr extends Prayer implements AudioReminder {

    public Dhuhr(String time) {
        super(time);
    }

    @Override
    public void remind() {
        System.out.println("Reminder: Waktunya Sholat Dzuhur pukul " + time);
    }

    @Override
    public void playAdzan() {
        System.out.println("Memutar adzan Dzuhur...");
    }
}