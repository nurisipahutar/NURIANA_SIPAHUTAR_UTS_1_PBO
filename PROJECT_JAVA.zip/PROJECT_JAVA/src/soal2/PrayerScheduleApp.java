package soal2;

public class PrayerScheduleApp {
    public static void main(String[] args) {
        // Membuat array jadwal sholat dengan polymorphism
        Prayer[] prayers = {
            new Fajr("04:52"),
            new Dhuhr("12:24"),
            new Asr("15:49"),
            new Maghrib("18:33"),
            new Isha("19:47")
        };

        // Loop untuk mengingatkan dan memutar adzan setiap sholat
        for (Prayer p : prayers) {
            p.remind();

            // Karena semua implementasi adalah AudioReminder, cast aman
            if (p instanceof AudioReminder) {
                ((AudioReminder) p).playAdzan();
            }

            System.out.println();
        }
    }
}
