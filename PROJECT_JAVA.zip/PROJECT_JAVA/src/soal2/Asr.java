package soal2;

public class Asr extends Prayer implements AudioReminder {

    public Asr(String time) {
        super(time);
    }

    @Override
    public void remind() {
        System.out.println("Reminder: Waktunya Sholat Ashar pukul " + time);
    }

    @Override
    public void playAdzan() {
        System.out.println("Memutar adzan Ashar...");
    }
}
