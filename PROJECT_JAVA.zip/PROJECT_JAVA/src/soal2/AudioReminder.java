package soal2;

public interface AudioReminder {
    void playAdzan();
}
